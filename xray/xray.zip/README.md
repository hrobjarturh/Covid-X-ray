# Dash Exploration of COVID-19 chest X-ray CT images

This app shows how to explore 3-D chest tomography data using Dash. 

The data used in this app come from the open dataset of
https://github.com/ieee8023/covid-chestxray-dataset

## License
All rights belong to [2021.ai](https://2021.ai/)


## Resources

To learn more about Dash, please visit [documentation](https://plot.ly/dash).
